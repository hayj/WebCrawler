# coding: utf-8

from pymongo import MongoClient
import pandas as pd
import time
from systemtools.logger import log, logInfo, logWarning, logWarning, logError, Logger
from systemtools.basics import *
import urllib

# TODO expireAfterSeconds: <int> Used to create an expiring (TTL) collection. MongoDB will automatically delete documents from this collection after <int> seconds. The indexed field must be a UTC datetime or the data will not expire.
# unique: if True creates a uniqueness constraint on the index.
#  my_collection.create_index([("mike", pymongo.DESCENDING), # on peut mettre HASHED
#                             ("eliot", pymongo.ASCENDING)]) # Par default ascending

class MongoCollection():
    def __init__ \
    (
        self,
        dbName,
        collectionName,
        version=None,
        indexOn=None,
        indexNotUniqueOn=None,
        giveTimestamp=True,
        verbose=True,
        logger=None,
        user=None,
        password=None,
        port="27017",
        host=None,
        databaseRoot=None,
    ):
        # All vars :
        self.logger = logger
        self.port = port
        self.host = host
        self.user = user
        self.password = password
        self.password = urllib.parse.quote_plus(self.password)
        self.verbose = verbose
        self.version = version
        self.dbName = dbName
        if indexOn is not None:
            if not isinstance(indexOn, list):
                indexOn = [indexOn]
        if indexNotUniqueOn is not None:
            if not isinstance(indexNotUniqueOn, list):
                indexNotUniqueOn = [indexNotUniqueOn]
        self.indexOn = indexOn
        self.indexNotUniqueOn = indexNotUniqueOn
        self.giveTimestamp = giveTimestamp
        self.collectionName = collectionName
        self.databaseRoot = databaseRoot
        if self.databaseRoot is None:
            self.databaseRoot = ""
        
        if self.host is not None:
            self.host = "mongodb://" + self.user + ":" + self.password + "@" + self.host + ":" + self.port + "/" + self.databaseRoot
        
        # And init the db :
        self.initDataBase()
        
    def initDataBase(self):
        self.client = MongoClient(host=self.host)
        self.db = self.client[self.dbName]
        self.collection = self.db[self.collectionName]
        if self.indexOn is not None and len(self.indexOn) > 0:
            for currentIndexOn in self.indexOn:
                self.collection.create_index(currentIndexOn, unique=True)
        if self.indexNotUniqueOn is not None and len(self.indexNotUniqueOn) > 0:
            for currentIndexOn in self.indexNotUniqueOn:
                self.collection.create_index(currentIndexOn, unique=False)
        if self.verbose:
            print(self.title())
    
    def title(self):
        result = self.dbName + " " + self.collectionName
        if self.version is not None:
            result += " (version " + str(self.version) + ")"
        result += " initialised."
        return result
            
    
    def removeRowsVersion(self, version):
        pass # TODO
    
    @staticmethod
    def userAllow(elementName="the data"):
        answer = input('Do you confirm ' + elementName + ' removal ? (y/n)')
        if answer == "y":
            return True
        return False
        
    def resetCollection(self, security=True):
        if not security or MongoCollection.userAllow("the collection"):
            self.collection.drop()
            self.initDataBase()
        
    def resetDatabase(self, security=True):
        if not security or MongoCollection.userAllow("the database"):
            self.client.drop_database(self.dbId)
            self.initDataBase()
    
    def getIndexesSize(self):
        count = 0
        for _ in self.collection.list_indexes():
            count += 1
        return count
    
    def toString(self):
        result = ""
        for entry in self.collection.find({}):
            result += self.entryToString(entry) + "\n"
        return result
    
    def size(self):
        return self.collection.count({})
 
    def insert(self, row):
        if not isinstance(row, list) and not isinstance(row, dict):
            logError("row have to be list or dict")
        else:
            if not isinstance(row, list):
                row = [row]
            for currentRow in row:
                if self.version is not None:
                    currentRow["version"] = self.version
                if self.giveTimestamp:
                    timestamp = time.time()
                    currentRow["timestamp"] = timestamp
                self.collection.insert_one(currentRow)

    def find(self, query={}):
        return self.collection.find(query)
    
    def findOne(self, query={}):
        for current in self.collection.find(query):
            return current
        return None
    
    def deleteOne(self, query=None):
        if query is not None:
            try:
                return self.collection.delete_one(query)
            except Exception as e:
                logError(str(e), self)
        return None
    
    def toDataFrame(self, deleteMongoId=False):
        allRows= self.find()
        if deleteMongoId:
            for i in range(len(allRows)):
                allRows[i].pop("_id")
        df = pd.DataFrame(list(allRows))
        return df

    def has(self, query={}):
        for current in self.find(query):
            return True
        return False

def dictToMongoStorable(data):
    """
        This function convert all set() in list()
        and all "." in keys will be replaced by "_"
    """
    if data is None:
        return None
    if isinstance(data, set):
        return list(data)
    if not isinstance(data, dict):
        return data
    newData = {}
    for key, value in data.items():
        value = dictToMongoStorable(value)
        key = key.replace(".", "_")
        newData[key] = value
    return newData

def testDisplay():
    mc = MongoCollection("test", "collection1", verbose=True, indexOn="t")
    mc.resetCollection(security=False)
    for i in range(1000):
        mc.insert({"t": i})
    print(mc.toDataFrame())
    print("size", mc.size())

def testConvert():
    dict1 = {"a.b": {1, 2, 3, 3}, "b": {"c.n": None, "c_m": {"d.3": 1.0001}}}
    printLTS(dictToMongoStorable(dict1))

if __name__ == '__main__':
    testConvert()









