import pymongo
import random
import string
import time

dbName = "testdb"
collectionName = "test1"
host = "localhost"
port = "27017"
user = "hayj"
password = "K5Tv9G4191IfapG327Pnd6ft8IE49Igamv"

mongoConnectionScheme = "mongodb://" + user + ":" + password + "@" + host + ":" + port

myclient = pymongo.MongoClient(mongoConnectionScheme)
mydb = myclient[dbName]

mycol = mydb[collectionName]


if mycol.count({}) < 100:
	mycol.create_index("id")
	mycol.delete_many({})
	for i in range(1000):
		text = ""
		for u in range(1000):
			text += ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
		o = {"timestamp": time.time(), "text": text, "id": i}
		mycol.insert_one(o)


i = 0
for row in mycol.find({}):
	print(row["id"])
	if i > 200:
		break
	i += 1



for row in mycol.find({}, projection={"id": True}):
	print(row["id"])
	if i > 200:
		break
