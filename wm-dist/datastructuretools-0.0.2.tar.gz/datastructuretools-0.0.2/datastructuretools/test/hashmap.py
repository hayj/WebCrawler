# coding: utf-8

from fr.hayj.datastructure.hashmap import *;
from fr.hayj.util.system import *;

import unittest

# The level allow the unit test execution to choose only the top level test 
unittestLevel = 1;

if unittestLevel <= 1: 
    class Test(unittest.TestCase):
        def setUp(self):
            pass
    
        def testLoadingAll(self):
            
            workingDirectory = getWorkingDirectory() + "/test_limitedhashmap.bin";
            hm = SerializableHashMap(workingDirectory);
            hm.clean();
            
            self.assertTrue(hm.getOne("test1") == None);
            self.assertTrue(hm.getOne("468748641") == None);
            
            hm.add("test1", 15);
            hm.add("test2", "yo");
            
            self.assertTrue(hm.getOne("test2") is not None);
            
            hm.serialize();
            
            hm.getOne("test1");
            
            hm2 = SerializableHashMap(workingDirectory);
            
            self.assertTrue(hm.getOne("test2") == hm2.getOne("test2"));
                        

        def testTryAgain(self):
            # to test the clean...
            self.testLoadingAll();
                        

        def testRecursive(self):
             
            workingDirectory = getWorkingDirectory() + "/test2_limitedhashmap.bin";
            hm = SerializableHashMap(workingDirectory);
            hm.clean();
             
            d = dict();
            d2 = dict();
            d2["test"] = 42;
            d["d2"] = d2;
            hm.add("d", d);
            hm.serialize();
             
             
            hm2 = SerializableHashMap(workingDirectory);
            self.assertTrue(hm2.getOne("d")["d2"]["test"] == d2["test"]);
            
        
        def testSentencePair(self):
            d = dict();
            obj = SentencePair('a', 'b');
            d[obj] = "yo"
            self.assertTrue(d[obj] == 'yo');
            self.assertTrue(SentencePair('a', 'b') in d);
            self.assertTrue(d[SentencePair('a', 'b')] == "yo");
            self.assertTrue((SentencePair('c', 'd') in d) == False);


