from datastructuretools import config as dstConfig
from datastructuretools.hashmap import *
dstConfig.user = "student"
dstConfig.password = "cs-lri-octopeek-984135584714323587326"
dstConfig.sdDatabaseName = "student"
sd = SerializableDict("sdtest", useMongodb=True, host="212.129.44.40")
sd["a"] = 1
print(sd["a"])