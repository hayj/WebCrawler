
from systemtools.basics import *
from systemtools.duration import *
from systemtools.printer import *
from datastructuretools.midict import *
from threading import Lock


class CacheStringIndex(int):
    def __new__(cls, value, *args, **kwargs):
        return super(CacheStringIndex, cls).__new__(cls, value)

class FakeCache:
	def __init__(self, getter, **kwargs):
		self.getter = getter

	def __contains__(self, key):
		return False
	def __delitem__(self, key):
		pass
	def __enter__(self):
		return self
	def stop(self):
		pass
	def purge(self):
		pass
	def __getitem__(self, key):
		return self.get(key)


class Cache:
	"""
		A dict-like class that periodicaly clean values receiving less actions (read / write). It remove values randomly among those having less actions until reaching a certain amount of free RAM. The cleaning process is a background thread that check the free RAM each 0.5 sec by default.

		When using a Cache instance, don't forget to purge it (using `purge()` which stop the intern timer or using the with statement) because the timer that launch the periodic cleaning will keep a reference of the instance, thus the garbage collector won't remove the instance from RAM.

		Use actionCleanInterval to clean each n seconds actions. So the cache will forget count of keys that were deleted from the cache. This process will also set all actions to 1. Prevent to have a very large actions count when you have combinason of keys for instance.
	"""
	def __init__\
	(
		self,
		getter,
		name=None,
		minFreeRAM=2.0,
		cleanInterval=0.5,
		actionCleanInterval=None,
		cleanRatio=20/100,
		indexStrings=False,
		fake=False,
		logger=None,
		verbose=True,
		addLoggerToKwargs=False,
	):
		self.addLoggerToKwargs = addLoggerToKwargs
		self.logger = logger
		self.verbose = verbose
		self.getter = getter
		self.name = name
		self.minFreeRAM = minFreeRAM
		self.cleanInterval = cleanInterval
		self.actionCleanInterval = actionCleanInterval
		self.cleanRatio = cleanRatio
		self.indexStrings = indexStrings
		self.fake = fake
		# We init all data:
		self.strMIDict = None
		self.strNewIndex = CacheStringIndex(0)
		self.purged = False
		self.data = dict()
		self.actions = MIDict()
		# We init the timer that will clean data each n seconds:
		self.lock = Lock()
		self.timer = Timer(self.__clean, self.cleanInterval, sleepFirst=True)
		self.actionsTimer = None
		if self.actionCleanInterval is not None:
			self.actionsTimer = Timer(self.__actionsClean, self.actionCleanInterval, sleepFirst=True)
		self.start()
	
	def assertNotPurged(self):
		if self.purged:
			raise Exception("The cache was purged, you cannot use it anymore.")
	def assertNotFake(self):
		if self.fake:
			raise Exception("The cache is a fake, you cannot do this.")

	def start(self):
		if not self.fake:
			self.timer.start()
			if self.actionsTimer is not None:
				self.actionsTimer.start()
	def __enter__(self):
		return self

	def stop(self):
		self.purge()
	def __del__ (self):
		self.purge()
	def purge(self):
		"""
			Purges the data and stop the periodic cleaning.

			See https://stackoverflow.com/questions/1481488/what-is-the-del-method-how-to-call-it/2452895
			And https://stackoverflow.com/questions/1984325/explaining-pythons-enter-and-exit
			The timer keep a ref of self, we need to stop it so th gc can collect the instance.
			So we use either the __init__ and `stop` or the with statment

			A good solution would be to just stop the timer instead of setting `self.data` to None, but after many test in a notebook, the garbage collector do not free the RAM (afetr a `c.purge() ; del c` or using the with statement) until we try to access to the instance `c` and getting a None exception... don't know why...
			Probably du to the timer... a solution would be to don't use a timer but cleaning at each set or get...
		"""
		self.timer.stop()
		if self.actionsTimer is not None:
			self.actionsTimer.stop()
		self.data = None
		self.purged = True
	def __exit__ (self, type, value, tb):
		self.purge()

	def __contains__(self, key):
		"""
			Check if a key exists in data. Can return False in case the value was removed.
		"""
		key = self.__toIndexKey(key)
		return key in self.data

	def __delitem__(self, key):
		"""
			Delete a single key from the cache, can raise KeyError.
		"""
		key = self.__toIndexKey(key)
		del self.data[key]

	def __toOriginalKey(self, key):
		if self.indexStrings and isinstance(key, tuple):
			newKey = []
			for e in key:
				if isinstance(e, CacheStringIndex):
					newKey.append(self.strMIDict[:,e][0])
				else:
					newKey.append(e)
			key = tuple(newKey)
		return key

	def __toIndexKey(self, key):
		if self.indexStrings and isinstance(key, tuple):
			if self.strMIDict is None:
				self.strMIDict = MIDict(logger=self.logger, verbose=self.verbose)
			newKey = []
			for e in key:
				if isinstance(e, str):
					if len(self.strMIDict[e,:]) == 0:
						self.strMIDict[e] = self.strNewIndex
						self.strNewIndex = CacheStringIndex(self.strNewIndex + 1)
					newKey.append(self.strMIDict[e,:][0])
				else:
					newKey.append(e)
			key = tuple(newKey)
		return key

	def remove(self, keys):
		"""
			Safely (no error) delete keys (or a single key) from the cache (if not already removed).
		"""
		with self.lock:
			if not isinstance(keys, list):
				keys = [keys]
			for key  in keys:
				if key in self.data:
					del self.data[key]

	def __getitem__(self, key):
		"""
			Returns an item by its key. Use `get(key, *args, **kwargs)` to give args that will be used by the getter function.
		"""
		return self.get(key)

	def __getterKwargs(self, kwargs):
		if self.addLoggerToKwargs:
			if 'logger' not in kwargs:
				kwargs['logger'] = self.logger
			if 'verbose' not in kwargs:
				kwargs['verbose'] = self.verbose
		return kwargs

	def get(self, key, *args, **kwargs):
		"""
			Returns the value corresponding to the key given. It will use the getter function if the key was not already loaded or was delete by the periodic clean.
		"""
		with self.lock:
			if self.fake:
				return self.getter(key, *args, **self.__getterKwargs(kwargs))
			else:
				key = self.__toIndexKey(key)
				self.assertNotPurged()
				if key in self.data:
					value = self.data[key]
				else:
					value = self.getter(self.__toOriginalKey(key), *args, **self.__getterKwargs(kwargs))
					self.data[key] = value
				self.__action(key)
				return self.data[key]

	def __setitem__(self, key, value):
		with self.lock:
			self.assertNotPurged()
			key = self.__toIndexKey(key)
			self.data[key] = value
			self.__action(key)

	def __len__(self):
		"""
			Returns the length of the actual data (values could be removed by the periodic clean).
		"""
		self.assertNotPurged()
		return len(self.data)

	def items(self):
		self.assertNotPurged()
		return self.data.items()

	def keys(self):
		self.assertNotPurged()
		return self.data.keys()

	def __action(self, key):
		key = self.__toIndexKey(key)
		if len(self.actions[key, :]) == 0:
			self.actions[key, :] = 0
		self.actions[key,:] = self.actions[key,:][0] + 1

	def __minaction(self):
		for i in range(len(self.actions.distinct(1))):
			currentCount = i + 1
			if len(self.actions[:, currentCount]) > 0:
				keys = [key for key in self.actions[:, currentCount] if key in self.data]
				if len(keys) > 0:
					return keys

	def __clean(self):
		"""
			Clean 1% of data iteratively until reaching minFreeRAM
		"""
		with self.lock:
			if not self.purged:
				cleanCount = 0
				tt = TicToc()
				tt.tic(display=False)
				while freeRAM() < self.minFreeRAM:
					toRemove = self.__minaction()
					if toRemove is None or len(toRemove) == 0:
						break
					else:
						amount = int(self.cleanRatio * len(self.data))
						if amount == 0:
							amount = 1
						if amount > len(toRemove):
							amount = len(toRemove)
						# toRemove = shuffle(toRemove)[:amount]
						toRemove = random.sample(toRemove, amount)
						for key in toRemove:
							del self.data[key]
							cleanCount += 1
				duration = tt.toc(display=False)
				duration = secondsToHumanReadableDuration(duration)
				if cleanCount > 0:
					if self.name is not None:
						message = str(cleanCount) + " values cleaned (" + duration + ") from " + self.name
					else:
						message = str(cleanCount) + " values cleaned from " + str(self)
					logWarning(message, self)

	def __actionsClean(self):
		with self.lock:
			if not self.purged:
				tt = TicToc()
				tt.tic(display=False)
				cleanCount = 0
				notCleanCount = 0
				for key in self.actions.distinct(0):
					if key in self.data:
						self.actions[key, :] = 1
						notCleanCount += 1
					else:
						del self.actions[key, :]
						cleanCount += 1
				duration = tt.toc(display=False)
				duration = secondsToHumanReadableDuration(duration)
				if cleanCount > 0:
					message = str(cleanCount) + " actions cleaned on " + str(cleanCount + notCleanCount) + " so " + str(truncateFloat(cleanCount / (cleanCount + notCleanCount) * 100, 2)) + "% (" + duration + ")"
					if self.name is not None:
						message += " from " + self.name
					logWarning(message, self)

	def printState(self, verbosity=2, markerLength=10):
		self.assertNotPurged()
		if self.name is not None:
			log("#" * markerLength + " " + self.name + " " + "#" * markerLength, self)
		if len(self) == 0:
			log("Empty cache.", self)
		else:
			log("Keys: " + b(self.data.keys(), verbosity) + " (" + str(len(self)) + ")", self)
			log("Count index: " + b(self.actions.distinct(1), verbosity), self)
			log("Action count: " + b(self.actions.items(), verbosity), self)
		if self.name is not None:
			log("#" * (markerLength * 2 + 2 + len(self.name)), self)