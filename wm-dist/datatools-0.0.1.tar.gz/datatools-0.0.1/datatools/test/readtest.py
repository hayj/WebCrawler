
import csv

csvData = csv.reader(open("/home/hayj/Data/Misc/news-website-list/data/list.csv", newline=''),
                                delimiter='\t',
                                quotechar='|',
                                quoting=csv.QUOTE_NONNUMERIC,
                                 )
for current in csvData:
    print(current)