# coding: utf-8

import publicsuffix
from publicsuffix import PublicSuffixList
from urllib.parse import urlparse
from enum import Enum
from systemtools.file import *
from systemtools.location import *
from systemtools.basics import *
from datatools.csvreader import *
import codecs
import re

URLLEVEL = Enum('URLLEVEL', 'ALL SMART ONE TWO')

class URLParser():
    def __init__(self, pslCachePath="./tmp/psl.txt", timeSpentMax=1):
        self.pslCachePath = pslCachePath
        self.timeSpentMax = timeSpentMax
        self.psl = None
        # self.initPublicSuffixList()
        self.urlEnhanceRegex = re.compile('^(?:http|ftp|https)://.*')

    def normalize(self, url):
        if url is None:
            return None
        url = url.strip()
        if not self.urlEnhanceRegex.match(url):
            url = "http://" + url
        return url

    def isImage(self, url):
        parsedUrl = self.parse(url)
        path = parsedUrl.path
        if re.match(".*\.(jpg|png|gif)$", path):
            return True
        return False

    def initPublicSuffixList(self):
        if self.psl is not None:
            return self.psl
        if fileExists(self.pslCachePath) and getLastModifiedTimeSpent(self.pslCachePath, TIMESPENT_UNIT.DAYS) < self.timeSpentMax:
            self.psl = codecs.open(self.pslCachePath, encoding='utf8')
        else: 
            (dir, filename, ext, filenameExt) = decomposePath(self.pslCachePath)
            mkdirIfNotExists(dir)
            self.psl = list(publicsuffix.fetch())
            removeIfExists(self.pslCachePath)
            strToFile(self.psl, self.pslCachePath)
        self.psl = PublicSuffixList(self.psl)
        return self.psl
    
    def getSmartDomain(self, domain):
        """
            This method return a smart domain given a domain.
            It remove subdomains and take into account public suffix list.
            Examples : "www.newsnow.co.uk" gives "newsnow.co.uk", "www.google.com"
            gives "google.com" and "test.com" gives "test.com"
        """
        if domain is None:
            return None
        domain = domain.strip()
        if domain == "":
            return None
        domain = domain.lower()
        self.initPublicSuffixList()
        return self.psl.get_public_suffix(domain)

    def getDomain(self, url, urlLevel=URLLEVEL.SMART):
        """
            This method gives a domain from an url. URLLEVEL.SMART refer to getSmartDomain.
        """
        if url is None:
            return None
        url = self.normalize(url)
        parsedUri = urlparse(url)
        domain = '{uri.netloc}'.format(uri=parsedUri)
        domain = domain.lower()
        if urlLevel == URLLEVEL.ALL:
            return domain
        elif urlLevel == URLLEVEL.ONE:
            theSplit = domain.split(".")
            if len(theSplit) > 0:
                return theSplit[-1]
            else:
                return None
        elif urlLevel == URLLEVEL.TWO:
            theSplit = domain.split(".")
            if len(theSplit) > 1:
                return ".".join(theSplit[-2:])
            else:
                return None
        elif urlLevel == URLLEVEL.SMART:
            return self.getSmartDomain(domain)
    
    def parse(self, url):
        if url is None:
            return None
        url = self.normalize(url)
        return urlparse(url)
    


if __name__ == '__main__':
    urlParser = URLParser()
    print(urlParser.getDomain("http://www.newsnow.co.uk/h/", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("https://www.github.com/test", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("https://truc.github.com/test", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("https://truc.gitb.com/test", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("http://decoetart.over-blog.com/", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("http://www.bbc.com/news/world-us-canada-41543631", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("http://www.huffingtonpost.co.za/2017/10/08/zuma-has-dismissed-as-mischievous-claims-that-he-has-preferred-candidates-for-the-sabc-board_a_23236416/?utm_hp_ref=za-homepage", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("https://www.stuff.co.nz/business/small-business/97687085/wellington-restaurant-closes-after-selling-two-illegal-wines-and-a-beer", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("https://ipblv.blogspot.fr/", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("https://mamasworkpresents.tumblr.com/post/166151594535/this-is-a-best-love-quote-from-didnt-know-it", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("https://careers.global/1/2503446/", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("member.nownews.com", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("news.china.com.cn", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("news.shm.com.cn", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("tw.trendmicro.com", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("www.dffy.com", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("www.halonoviny.cz", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("github.com", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("com", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain(None, urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("com.com", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("com.com.com", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("http:/t", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("http://t", urlLevel=URLLEVEL.SMART))
    print(urlParser.getDomain("http://www.newsnow.co.uk/h/", urlLevel=URLLEVEL.ONE))
    print(urlParser.getDomain("http://www.newsnow.co.uk/h/", urlLevel=URLLEVEL.TWO))
    print(urlParser.getDomain("http://www.newsnow.co.uk/h/", urlLevel=URLLEVEL.ALL))


    print(urlParser.parse("http://www.google.com/truc/test.html;param1;parm2;?test=1&truc=2#id1"))


#     



#     from proxietest import *
#     taoUrlGenerator = TaoUrlGenerator(dataPath)
#     for theDict in taoUrlGenerator:
#         if len(getDomain(theDict["url"]).split(".")) > 3:
#             print(theDict["url"])
#             print(getSmartDomain(theDict["url"]))
#             print()
#             input()

#     print(getDomain("aaram.net"))
#     print(getDomain("www.aaram.net"))
#     print(getDomain("http://www.aaram.net"))
        
#     cr = CsvReader('/home/hayj/Dashboard/Notes/Recherche/news-website-list/google-news-sources.csv')
#     for row in cr:
#         print(row["url"])
#         print(getSmartDomain(row["url"]))
#         print()
#         input()
    
#     print(listToStr2(getPublicSuffixList()))

