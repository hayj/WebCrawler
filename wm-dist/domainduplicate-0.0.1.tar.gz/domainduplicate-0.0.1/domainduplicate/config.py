useMongodb = True
user = None
password = None
host = None