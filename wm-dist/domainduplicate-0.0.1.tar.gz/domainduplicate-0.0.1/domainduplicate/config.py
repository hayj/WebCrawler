useMongodb = True
user = None
hostname = "datascience01"
user = "hayj"
password = None
host = None