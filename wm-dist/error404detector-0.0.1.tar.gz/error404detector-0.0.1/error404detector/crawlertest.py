from webcrawler.crawler import *

def crawlingCallback(data, browser=None):
    print(data)

crawler = Crawler(["https://github.com/hayj/WebCrawler"],
                  crawlingCallback=crawlingCallback,
#                 proxies=getProxiesTest(),
                  browserCount=1,
                  browserParams={"chromeDriverPath": "/home/hayj/Programs/browserdrivers/chromedriver"})
crawler.start()

