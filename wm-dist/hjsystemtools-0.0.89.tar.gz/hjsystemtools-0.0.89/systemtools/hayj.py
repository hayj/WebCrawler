
from enum import Enum
from systemtools.logger import *
from systemtools.location import *
from systemtools.basics import *
from systemtools.system import *
from datatools.dataencryptor import *
import json





# MONGO_SERVERS = Enum("MONGO_SERVERS", "localhost datascience01 hjlat jamy tipi")
# def getMongoAuth(user="hayj", mongoServer=MONGO_SERVERS.localhost, passwordsPath=None):
def getMongoAuth(user=None,
                 hostname="localhost",
                 logger=None,
                 verbose=True):
    """
        (user, password, host) = getMongoAuth()
    """
#     def jsonFileToObject(path):
#         with open(path) as data:
#             data = jsonToObject(data)
#         return data
#     def jsonToObject(text):
#         return json.load(text)
    host = "localhost"
#     if mongoServer == "datascience01" and not isHostname("datascience01"):
    if hostname == "datascience01" and not isHostname(hostname):
        host = "212.129.44.40" # 212.129.44.40
    try:
        passwords = DataEncryptor()["mongoauth"]["datascience01"]
    except Exception as e:
        logException(e, logger, message="Encrypted data in ~/.ssh/encrypted-data not found, a localhost mongodb auth will be used...",
                 verbose=verbose)
        return getLocalhostMongoAuth()

    password = None
    if user is not None:
        password = passwords[user]
    return (user, password, host)

def getOctodsMongoAuth(*args, **kwargs):
    return getDatascience01MongoAuth(*args, **kwargs)
def getDatascience01MongoAuth(*args, **kwargs):
    return getMongoAuth(*args, user="hayj", hostname="datascience01", **kwargs)
def getStudentMongoAuth(*args, **kwargs):
    return getMongoAuth(*args, user="student", hostname="datascience01", **kwargs)
def getLocalhostMongoAuth(*args, **kwargs):
    if isHostname("datascience01"):
        return getOctodsMongoAuth(*args, **kwargs)
    else:
        return (None, None, "localhost")

# def homeDir(user=None, homePaths=["/users/modhel", "/home"]):
#     if user is None:
#         user = getpass.getuser()
# #         if user in ["root", "admin", "superuser", "mongo", "mongod", "pydev"]:
# #             user = defaultUser
#     for currentHomePath in homePaths:
#         currentPath = currentHomePath + "/" + user
#         if isDir(currentPath):
#             return currentPath
#     return None

# def dataPath(dirname="Data", startDirs=["/users/modhel-nosave/hayj", "/home/hayj"], subDirSamples=["Similarity", "TwitterArchiveOrg"]):
#     walkParams = {"followlinks": True, "topdown": False}
#     pathSamples = []
#     for current in subDirSamples:
#         pathSamples.append(dirname + "/" + current)
#     for startDir in startDirs:
#         for root, dirs, files in os.walk(startDir, topdown=False):
#             for name in dirs:
#                 thePath = os.path.join(root, name)
#                 for sample in pathSamples:
#                     if re.match("^.*" + sample + "$", thePath) is not None:
#                         return "/".join(thePath.split("/")[0:-1])
#     return None

if __name__ == '__main__':
    print(getOctodsMongoAuth())
