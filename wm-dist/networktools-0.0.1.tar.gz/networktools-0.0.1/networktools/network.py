# coding: utf-8

import sys
import zmq
import threading
import time
from threading import Thread
import time
import os
import subprocess
import re
import json
from systemtools.basics import *


class Messenger():
    """
    INFO: the fromRemotePublisher return received messages as a FIFO queue
    """
    def __init__(self, outPort, inPort,
                 logFunct=None,
                 killOthersProcess=False,
                 waitForKilled=True,
                 waitForAnswered=False,
                 timeout=None,
                 verbose=True,
                 parseOutputToJson=False,
                 parseInputToJson=False):
        self.firstMessage = "MessengerFirstMessage"
        self.firstMessageResponse = "MessengerFirstMessageResponse"
        self.logFunct = logFunct
        self.parseInputToJson = parseInputToJson
        self.parseOutputToJson = parseOutputToJson
        self.verbose = verbose
        self.outPort = outPort
        self.inPort = inPort
        self.timeout = timeout
        self.zmqContext = None
        if killOthersProcess:
            killProcessOnPorts(self.outPort, wait=waitForKilled)
        self.remotePublisher = self.generateRemotePublisher()
        self.remoteSubscriber = self.generateRemoteSubscriber()
        
        if waitForAnswered:
            self.waitForAnswered()
    
    def wfaSender(self):
        self.firstMessageReceived = False
        while not self.firstMessageReceived:
            self.log("Sending first message...")
            self.toRemoteSubscriber(self.firstMessage)
            time.sleep(0.1)
    
    def wfaReceiver(self):
        message = None
        while message != self.firstMessageResponse:
            message = self.remotePublisher.recv_string()
            self.log("Answer of the first message received...")
        self.firstMessageReceived = True
    
    def waitForAnswered(self):
        receiver = Thread(target = self.wfaReceiver)
        receiver.start()
        sender = Thread(target = self.wfaSender)
        sender.start()
        receiver.join()
    
    def generateRemotePublisher(self):
        """
        ZMQ_SUBSCRIBE: Establish message filter
        The ZMQ_SUBSCRIBE option shall establish a new message filter on a ZMQ_SUB socket. Newly created ZMQ_SUB sockets shall filter out all incoming messages, therefore you should call this option to establish an initial message filter.
        An empty option_value of length zero shall subscribe to all incoming messages. A non-empty option_value shall subscribe to all messages beginning with the specified prefix. Multiple filters may be attached to a single ZMQ_SUB socket, in which case a message shall be accepted if it matches at least one filter.
        """
        port = self.inPort
        if self.zmqContext is None:
            self.zmqContext = zmq.Context()
        if isinstance(port, int):
            port = str(port)
        remotePublisher = self.zmqContext.socket(zmq.SUB)
        remotePublisher.connect("tcp://localhost:" + port)
        remotePublisher.setsockopt_string(zmq.SUBSCRIBE, "")
#         if self.timeout is not None:
#             remotePublisher.setsockopt(zmq.RCVTIMEO, self.timeout)
        return remotePublisher
    
    def generateRemoteSubscriber(self):
        port = self.outPort
        if self.zmqContext is None:
            self.zmqContext = zmq.Context()
        if isinstance(port, int):
            port = str(port)
        zmqContext = zmq.Context()
        remoteSubscriber = zmqContext.socket(zmq.PUB)
        remoteSubscriber.bind("tcp://*:" + port)
        return remoteSubscriber
    
    def log(self, message):
        if self.verbose:
            message = "Messenger: " + message
            if self.logFunct is not None:
                self.logFunct(message)
            else:
                print(message)
    
    def send(self, *args, **kwargs):
        self.toRemoteSubscriber(*args, **kwargs)
    def receive(self, *args, **kwargs):
        self.fromRemotePublisher(*args, **kwargs)
    
    def toRemoteSubscriber(self, message):
        try:
            if self.parseInputToJson:
                if not isinstance(message, str):
                    message = objectToJsonStr(message)
                    print(listToStr(message))
            self.remoteSubscriber.send_string(message)
        except:
            if self.verbose:
                self.log("toRemoteSubscriber fail...")
        
    def fromRemotePublisher(self, timeout=None):
        if timeout is None:
            timeout = self.timeout
        if timeout is not None:
            self.remotePublisher.setsockopt(zmq.RCVTIMEO, timeout)
        try:
            message = self.remotePublisher.recv_string()
            if message == self.firstMessage:
                toPrint = self.firstMessage + " received."
                self.log(toPrint)
                self.toRemoteSubscriber(self.firstMessageResponse)
                self.log(self.firstMessageResponse + " sent.")
                return self.fromRemotePublisher()
            elif message == self.firstMessageResponse:
                toPrint = self.firstMessageResponse + " ok."
                self.log(toPrint)
                return self.fromRemotePublisher()
            else:
                if self.parseOutputToJson:
                    message = json.loads(message)
                return message
        except:
            if self.verbose:
                self.log("Timeout")
            return None

def killProcessOnPorts(ports, wait=True):
    exists = False
    if not isinstance(ports, list):
        ports = [ports]
    for i in range(len(ports)):
        if isinstance(ports[i], int):
            ports[i] = str(ports[i])
    def getPids(ports):
        popen = subprocess.Popen(['netstat', '-lpn'],
                                 shell=False,
                                 stdout=subprocess.PIPE)
        (data, err) = popen.communicate()
        pattern = "^tcp.*((?:{0})).* (?P<pid>[0-9]*)/.*$"
        pattern = pattern.format(')|(?:'.join(ports))
        prog = re.compile(pattern)
        pids = []
        for line in data.split('\n'):
            match = re.match(prog, line)
            if match:
                exists = True
                pid = match.group('pid')
                pids.append(pid)
        pids = list(set(pids))
        return pids
    pids = getPids(ports)
    for pid in pids:
        subprocess.Popen(['kill', '-9', pid])
    if wait:
        while len(getPids(ports)) > 0: pass



def getSecondPort(begin):
    now = time.time()
    second = int(now % 60)
    port = begin + second
    return port

    
if __name__ == '__main__':
    msger = Messenger(5550, 5551, timeout=1000)
    print(msger.fromRemotePublisher())








