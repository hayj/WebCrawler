
import re
from enum import Enum
from multiprocessing import Lock
from systemtools.location import *
from systemtools.file import *
from systemtools.basics import *
from datatools.htmltools import *

def countOverlaps(parsed1, parsed2, ngram):
    count = 0
    for _ in yieldOverlaps(parsed1, parsed2, ngram):
        count += 1
    return count

def hasOverlap(parsed1, parsed2, ngram):
    for _ in yieldOverlaps(parsed1, parsed2, ngram):
        return True
    return False

def yieldOverlaps(parsed1, parsed2, ngram):
    if len(parsed1) < ngram or len(parsed2) < ngram:
        return 0
    for i in range(len(parsed1) - (ngram - 1)):
        currentParsed1Ngram = parsed1[i:i + ngram]
        for i in range(len(parsed2) - (ngram - 1)):
            currentParsed2Ngram = parsed2[i:i + ngram]
            if currentParsed1Ngram == currentParsed2Ngram:
                yield currentParsed1Ngram

def magicNormalizeText(text, chevronMaxCount=5):
    if text is None or len(text) == 0:
        return None
    if text.count('<') > chevronMaxCount and text.count('>') > chevronMaxCount:
        text = html2Text(text)
    text = normalizeQuoteText(text)
    text = reduceBlank(text, keepNewLines=True)
    return text

def normalizeQuoteText(texts):
    if not isinstance(texts, list):
        texts = [texts]
    newTexts = []
    for current in texts:
        current = current.replace("''", '"')
        current = current.replace("``", '"')
        current = current.replace("``", '"')
        current = current.replace("`", "'")
        current = current.replace("’", "'")
        current = current.replace("’", "'")
        current = current.replace("”", '"')
        current = current.replace("“", '"')
        newTexts.append(current)
    texts = newTexts
    if len(texts) == 1:
        return texts[0]
    else:
        return texts

def lower(theString):
    return theString.lower()

def isNotWord(token):
    # and word not in ['-lrb-', '-rrb-', '-lsb-', '-rsb-', '-lcb-', '-rcb-']
    if re.search('([a-z]|[A-Z]|[0-9])', token) is not None:
        return False
    else:
        return True

def removeNotWords(*args, **kwargs):
    return removeNotWord(*args, **kwargs)
def removeNotWord(tokens):
    newTokens = []
    for token in tokens:
        if not isNotWord(token):
            newTokens.append(token)
    return newTokens



# TODOOOOOOOOOOOOOO faire en sorte de faire une class topwords pour gérer l'init et le lock ? une seul  ouverture de fichier contrirement à la

STOPWORDS_LIST = Enum("STOPWORDS_LIST", "large small")
stopwordsSingleton = None
# stopwordsLock = Lock()
def initStopwordsList(stopwordsList=STOPWORDS_LIST.small):
    global stopwordsLock
    global stopwordsSingleton
    # with stopwordsLock: 
    if stopwordsSingleton is None:
        stopwordsSingleton = dict()
    if stopwordsList.name not in stopwordsSingleton:
        path = execDir(__file__) + "/data/stopwords/stopwords-" + stopwordsList.name + ".txt"
        stopwordsSingleton[stopwordsList.name] = set(fileToStrList(path))
def removeStopWords(*args, **kwargs):
    return removeStopwords(*args, **kwargs)
def removeStopwords(tokens, stopwordsList=STOPWORDS_LIST.small):
    global stopwordsLock
    global stopwordsSingleton
    initStopwordsList(stopwordsList=stopwordsList)
    newTokens = []
    for token in tokens:
        if token not in stopwordsSingleton[stopwordsList.name]:
            newTokens.append(token)
    return newTokens
def removeStopwordsLarge(tokens):
    return removeStopwords(tokens, stopwordsList=STOPWORDS_LIST.large)