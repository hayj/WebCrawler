
from datastructuretools.processing import *
from systemtools.basics import *
from systemtools.logger import *
from systemtools.system import *
from nlptools.tokenizer import *
from nlptools.basics import *

# TODO faire une fonction qui score chaque document en fonction de à quel point il overlap sur l'ensemble

class Overlap():
	def __init__(self, documents, logger=None, verbose=True, preprocess=True,
		parallelCount=None, ngramsMin=3, removeEmbeddedNgrams=True, batchMaxSize=500):
		"""
			:params batchMaxSize: will split your documents in maximum size of `batchMaxSize`. You will generate approximation of overlaps because overlaps will be calculated on multiple sub-set of all documents and all ngrams will be merged. This parameter overcome the O(n2) complexity by approximating overlaps.
		"""
		self.removeEmbeddedNgrams = removeEmbeddedNgrams
		self.ngramsMin = ngramsMin
		self.parallelCount = parallelCount
		if self.parallelCount is None:
			self.parallelCount = cpuCount()
		self.documents = documents
		self.logger = logger
		self.overlaps = None
		self.overlapsScores = None
		self.verbose = verbose
		self.tt = TicToc(logger=self.logger)
		if isinstance(self.documents, set):
			self.documents = list(self.documents)
		if self.documents is None or len(self.documents) == 0:
			raise Exception("documents must be a list of documents.")
		self.poolParams = \
		{
			"parallelCount": self.parallelCount,
			"mapType": MAP_TYPE.multiprocessing,
			"logger": self.logger,
		}
		if not isinstance(self.documents[0], list) and preprocess:
			log("Preprocessing for Overlap...", self)
			self.tt.tic(display=False)
			self.normalize()
			self.lower()
			self.tokenize()
			self.removeNotWord()
			self.removeStopwords()
			self.tt.tic("Preprocessing done.")
		self.invertedIndex = None
		log("Generating the inverted index...", self)
		self.tt.tic(display=False)
		self.generateInvertedIndex()
		self.tt.tic("Inverted index generated.")


	def getInvertedIndex(self):
		return self.invertedIndex

	def getOverlapsScores(self):
		if self.overlapsScores is not None:
			return self.overlapsScores
		overlaps = self.getOverlaps()
		return self.invertedIndex

	def getDocuments(self):
		return self.documents

	def removeStopwords(self):
		initStopwordsList(stopwordsList=STOPWORDS_LIST.large)
		pool = Pool(**self.poolParams)
		self.documents = pool.map(removeStopwordsLarge, self.documents)

	def removeNotWord(self):
		pool = Pool(**self.poolParams)
		self.documents = pool.map(removeNotWord, self.documents)

	def lower(self):
		pool = Pool(**self.poolParams)
		self.documents = pool.map(lower, self.documents)

	def normalize(self):
		pool = Pool(**self.poolParams)
		self.documents = pool.map(normalizeText, self.documents)

	def tokenize(self):
		pool = Pool(**self.poolParams)
		self.documents = pool.map(tokenize, self.documents)

	def generateInvertedIndex(self):
		"""
			The inverted index is structured like this:
			{
				vouchers: 
				{
					3: [70, 291, <wordIndex>, ...],
					10: [2, 4, <wordIndex>, ...],
					<documentIndex>: [21, 42, <wordIndex>, ...],
				},
				<word>: 
				{
					3: [70, 291, <wordIndex>, ...],
					10: [2, 4, <wordIndex>, ...],
					<documentIndex>: [21, 42, <wordIndex>, ...],
				},
				...
			}
		"""
		self.invertedIndex = dict()
		documentIndex = 0
		for document in self.documents:
			wordIndex = 0
			for word in document:
				if word not in self.invertedIndex:
					self.invertedIndex[word] = dict()
				theDict = self.invertedIndex[word]
				if documentIndex not in theDict:
					theDict[documentIndex] = []
				theDict[documentIndex].append(wordIndex)
				wordIndex += 1
			documentIndex += 1

	def getOverlaps(self):
		if self.overlaps is None:
			return self.generateOverlaps()
		else:
			return self.overlaps

	def generateOverlaps(self):
		"""
			An overlaps structure looks like:
			{
				('la', 'soupe', 'aux', 'choux', <a word>): {
					0: {0},
					<the document index>: {0}
				},
				('la', 'soupe', 'aux', 'choux'): {
					0: {90, 146},
					1: {<the first word index>, <the first word index for an other occurrence of the ngram in the same document>}
				},
				('rené', 'fallet', 'paru', 'en'): {
					0: {6},
					1: {23}
				},
				<the ngram tuple>: {
					0: {27},
					1: {51}
				}
			}

			O(n2) but optimized with an inverted index

			--> tic: 2.65s for 100 docs.
			--> tic: 19.39s for 200 docs.
			--> tic: 1m 4.14s for 300 docs.
			--> tic: 2m 43.11s for 500 docs.
		"""
		if self.batchMaxSize is not None and self.batchMaxSize > 1:
			batchCount = math.ceil(len(self.documents / self.batchMaxSize))
			# TODO OOOOOOOOOOOOOOOOOO OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
		log("Generating overlaps...", self)
		self.tt.tic(display=False)
		pairs = []
		for i in range(len(self.documents)):
			for u in range(i, len(self.documents)):
				if i != u:
					pairs.append((i, u))
		pairs = split(pairs, self.parallelCount)
		pool = Pool(**self.poolParams)
		overlapss = pool.map(self.getOverlapsFromPairs, pairs)
		overlaps = self.overlapsFusion(overlapss)
		self.tt.tic("Overlaps generated.")
		self.overlaps = overlaps
		return overlaps

	def overlapsFusion(self, overlapss):
		newOverlaps = dict()
		for overlaps in overlapss:
			for ngram, docs in overlaps.items():
				if ngram not in newOverlaps:
					newOverlaps[ngram] = dict()
				newOverlaps[ngram] = mergeDicts(newOverlaps[ngram], docs)
		return newOverlaps


	def getOverlapsFromPairs(self, pairs):
		overlapss = []
		for index1, index2 in pairs:
			pairOverlaps = self.getOverlapsFromPair(index1, index2)
			if len(pairOverlaps) > 0:
				# strToFile(lts(self.documents[index1]) + "\n" * 10 + lts(self.documents[index2]), tmpDir() + "/test.txt")
				# printLTS(pairOverlaps)
				# exit()
				overlapss.append(pairOverlaps)
		overlaps = self.overlapsFusion(overlapss)
		return overlaps

	def getOverlapsFromPair(self, docIndex1, docIndex2):
		doc1 = self.documents[docIndex1]
		doc2 = self.documents[docIndex2]
		doc1Len = len(doc1)
		doc2Len = len(doc2)
		overlaps = dict()
		for wordIndex1 in range(len(doc1)):
			word = doc1[wordIndex1]
			inversedIndexEntry = self.invertedIndex[word]
			if docIndex2 in inversedIndexEntry:
				# Here we found indexes in doc2 for the word in doc1:
				for wordIndex2 in inversedIndexEntry[docIndex2]:
					i = 1
					while True:
						newIndex1 = wordIndex1 + i
						newIndex2 = wordIndex2 + i
						if newIndex1 >= doc1Len or newIndex2 >= doc2Len:
							break
						elif doc1[newIndex1] != doc2[newIndex2]:
							break
						else:
							i += 1
					ngramMaxIndex = i - 1
					ngramLength = ngramMaxIndex + 1
					if ngramLength >= self.ngramsMin:
						ngram = []
						for u in range(ngramLength):
							ngram.append(doc1[wordIndex1 + u])
						ngram = tuple(ngram)
						if ngram not in overlaps:
							overlaps[ngram] = dict()
						if docIndex1 not in overlaps[ngram]:
							overlaps[ngram][docIndex1] = set()
						if docIndex2 not in overlaps[ngram]:
							overlaps[ngram][docIndex2] = set()
						overlaps[ngram][docIndex1].add(wordIndex1)
						overlaps[ngram][docIndex2].add(wordIndex2)
		if self.removeEmbeddedNgrams:
			# First we remove embedded ngrams:
			for currentDocIndex in [docIndex1, docIndex2]:
				for ngram1, currentDocs1 in overlaps.items():
					ngram1Len = len(ngram1)
					wordIndexes1 = currentDocs1[currentDocIndex]
					for ngram2, currentDocs2 in overlaps.items():
						ngram2Len = len(ngram2)
						wordIndexes2 = currentDocs2[currentDocIndex]
						if ngram2Len > ngram1Len:
							toDelete = []
							for wordIndex1 in wordIndexes1:
								for wordIndex2 in wordIndexes2:
									# Maybe we have to delete the ngram1 occurrence (checking intervals):
									ngram2Interval = (wordIndex2, wordIndex2 + ngram2Len)
									ngram1Interval = (wordIndex1, wordIndex1 + ngram1Len)
									if ngram1Interval[0] >= ngram2Interval[0] and ngram1Interval[1] <= ngram2Interval[1]:
										toDelete.append(wordIndex1)
							for current in toDelete:
								wordIndexes1.remove(current)
			# Then we delete empty docIndex:
			for currentNgram, currentDocs in overlaps.items():
				docIndexesToDelete = []
				for currentDocIndex, wordIndexes in currentDocs.items():
					if len(wordIndexes) == 0:
						docIndexesToDelete.append(currentDocIndex)
				for current in docIndexesToDelete:
					del currentDocs[current]
			# Then we delete ngrams which appear only in one doc:
			ngramsToDelete = []
			for currentNgram, currentDocs in overlaps.items():
				if len(currentDocs) <= 1:
					ngramsToDelete.append(currentNgram)
			for current in ngramsToDelete:
				del overlaps[current]
		return overlaps


if __name__ == '__main__':
	pass












