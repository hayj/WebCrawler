
# pew in st-venv python ~/Workspace/Python/Utils/NLPTools/nlptools/preprocessing.py

import re
from enum import Enum
from multiprocessing import Lock
from systemtools.location import *
from systemtools.file import *
from systemtools.basics import * # stripAccents, reduceBlank
from datatools.htmltools import *
from datatools.url import *
from unidecode import unidecode

def softPreprocess(text, removeUrls=False, **kwargs):
	return preprocess\
	(
		text,
		removeHtml=True,
		doQuoteNormalization=False,
		doReduceBlank=True,
		keepNewLines=True,
		doUnidecode=False,
		removeUrls=removeUrls,
		doLower=False,
		**kwargs
	)

def hardPreprocess(text, removeUrls=False, doLower=False, **kwargs):
	"""
		You can use extractUrls before calling this function
	"""
	return preprocess\
	(
		text,
		removeHtml=True,
		doQuoteNormalization=True,
		doReduceBlank=True,
		keepNewLines=True,
		doUnidecode=True,
		removeUrls=removeUrls,
		doLower=doLower,
		**kwargs
	)

def tweetSoftPreprocess(*args, **kwargs):
	return softPreprocessing(*args, **kwargs)

def tweetHardPreprocess(*args, **kwargs):
	return hardPreprocessing(*args, **kwargs)

def lower(theString):
	return theString.lower()

def normalizeQuote(texts):
	"""
		Tested
	"""
	if not isinstance(texts, list):
		texts = [texts]
	newTexts = []
	for current in texts:
		current = re.sub("[‘’`']{2,}", '"', current)
		current = current.replace("”", '"')
		current = current.replace("“", '"')
		current = current.replace("`", "'")
		current = current.replace("’", "'")
		current = current.replace("‘", "'")
		newTexts.append(current)
	texts = newTexts
	if len(texts) == 1:
		return texts[0]
	else:
		return texts

def containsHtml(text):
	"""
		Tested
	"""
	if text is None:
		return False
	else:
		openingMarkupPattern = r"<[^<]+>"
		closingMarkupPattern = r"</[^<]+>"
		if re.search(openingMarkupPattern, text) and re.search(closingMarkupPattern, text):
			return True
		return False

def preprocess(text, logger=None, verbose=True, removeHtml=True, doQuoteNormalization=True, doReduceBlank=True, keepNewLines=True, doUnidecode=True, noneNonStrings=False, noneEmptyStrings=True, removeUrls=False, doLower=False):
	"""
		This function will convert all special chars (accents...) to ascii equivalent using unidecode. It will replace special usage of `` ´´ by it's equivalent, will replace '' by a doublequote etc. This function will also reduce blanks to unique space but will keep new lines. It will strip the string, remove the html.
		You can path a list of string or 

		TODO handle non utf-8 texts (ascii, bytes...)
	"""
	if text is None:
		return None
	# elif isinstance(text, list):
	# 	currentKwargs = \
	# 	{
	# 		"logger": logger, "verbose": verbose, "removeHtml": removeHtml, "doQuoteNormalization": doQuoteNormalization, "doReduceBlank": doReduceBlank, "keepNewLines": keepNewLines, "doUnidecode": doUnidecode, "noneNonStrings": noneNonStrings, "noneEmptyStrings": noneEmptyStrings, "removeUrls": removeUrls, "doLower": doLower,
	# 	}
	# 	result = []
	# 	for current in text:
	# 		result.append(preprocess(current, **currentKwargs))
	# 	return result
	elif isinstance(text, str):
		try:
			if removeHtml and containsHtml(text):
				text = html2Text(text)
			urls = None
			if removeUrls:
				text = removeUrls(text)
			else:
				(text, urls) = extractUrls(text)
			if doQuoteNormalization:
				text = normalizeQuote(text)
			if doUnidecode:
				text = unidecode(text)
			if doReduceBlank:
				text = reduceBlank(text, keepNewLines=keepNewLines)
			if not removeUrls:
				text = insertUrls(text, urls)
			if doLower:
				text = text.lower()
		except Exception as e:
			if text is None:
				message = None
			else:
				message = str(text)[:100]
			logException(e, logger=logger, message=message, verbose=verbose)
		if noneEmptyStrings and len(text) == 0:
			text = None
		return text
	else:
		logError("text must be a list or a str.",
			logger=logger, verbose=verbose)
		if noneNonStrings:
			return None
		else:
			return text

def preprocessTest():
	filesPath = sortedGlob(execDir(__file__) + "/test/testdata/preprocessing/*")
	for path in filesPath:
		text = fileToStr(path)
		print("-" * 50)
		print("--- ORIGINAL TEXT OF " + decomposePath(path)[3] + " ---")
		printLTS(text)
		print("\n" * 2) ; input()
		print("--- soft ---")
		printLTS(softPreprocess(text))
		print("\n" * 2) ; input()
		print("--- hard ---")
		printLTS(hardPreprocess(text))
		print("\n" * 2) ; input()
		print("\n" * 2)

if __name__ == '__main__':
	preprocessTest()
