from systemtools.basics import *
from nltk.tokenize import word_tokenize


def tokenize(obj):
    if obj is None:
        return None
    elif isinstance(obj, str):
        return word_tokenize(obj)
    elif isinstance(obj, list):
        return [tokenize(i) for i in obj]
    else:
        return obj # Or throw an exception, or parse a dict, a set...

# TODO OOO use the urlparser to replace url before tokenize
# TODO OOO remove series of punctuation pour que le modèle d'authorship attribution ne reconnaisse pas les "..." en fin de text par exemple. Sinon carrement remplacer tous les ">" ou "|" par des points,puis reéduire toutes les suites de punct à un seul point. Faire des tests pour voir le resultat. Aussi remplacer les retour ligne par des points.
# Voir comment faire un modèle robuste à la taille des articles  

if __name__ == "__main__":
    data = \
    [
        "jhg bfdguyjgfd fd gjd",
        [
            [
                ["ugtuyf", "vuhgvds"],
                None
            ],
            [
                [None],
                ["a", "b bdsf! id"]
            ],
        ],
        [
            [
                "jhsdg fjhdsg fgvsdk fksd ", None
            ],
            [
                "jhgsv defhgv sdufg uksdf jsd"
            ],
            "hjubvkujhv refgh. bvuljg ug udsfg li d. isdgf v . usdgf? sdvf ?"
        ],
    ]

    data = [["Lorem ipsum dolor. Sit amet?", "Hello World!", None], ["a"], "Hi!", None, ""]
    print(tokenize(data))