rm -rf ./data/scrolldata-*.txt
mkdir -p ./data
rsync -avhu ~/Data/Misc/crawling/scrolling/* ./data/

