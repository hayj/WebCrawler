# coding: utf-8

# tail -f /users/modhel/hayj/NoSave/TwitterTest/01/warning.log
# tail -f /users/modhel/hayj/NoSave/TwitterTest/01/info.log
# rm /users/modhel/hayj/NoSave/TwitterTest/01/info.log /users/modhel/hayj/NoSave/TwitterTest/01/warning.log
# ps -u hayj
################## ERROR sur 42941 ligne 2358 (dernière) : json mal formé

from systemtools.basics import *
from datatools.json import *
from systemtools.location import *
from systemtools.file import *
from systemtools.logger import *
from systemtools.duration import *

# Some init:
TEST = False 
entriesCountPerFile = 100000 # 100000 = 37 Mo uncompressed
# entriesCountPerFile = 100 # 100000 = 37 Mo uncompressed
if TEST:
    entriesCountPerFile = 1000
toKeep = ["text", "created_at", "retweeted", "id", "timestamp_ms", "lang"] # tranlate to tweet_id tweet_lang
toKeepInUser = ["id", "lang"] # translate to the top level : user_id and user_lang
fileIndex = 0

# Get all directories:
home = "/home/hayj"
# home = "/users/modhel/hayj/NoSave/"
root = home + "/Data/TwitterArchiveOrg"
if TEST:
    root += "/Test"
inputFilesPattern = root + "/Original/*/*/*/*/*.bz2"
outputPath = root + "/Converted/"
removeTreeIfExistsSecure(outputPath, slashCount=6)
mkdirIfNotExists(outputPath)

allLangs = []

# Create loggers:
info = Logger(outputPath + "/info.log")
warning = Logger(outputPath + "/warning.log")
# warning = Logger(home + "/langs.log")

def storeData(data, outputPath, logger=None):
    global fileIndex
    if len(data) > 0:
        filename = str(fileIndex)
        tt = TicToc(logger=logger)
        tt.tic("Starting compression of " + filename + "...")
        jsonListToLineJsonBz2(filename, data, outputPath, compresslevel=1)
        tt.tic("Compression done.")
        fileIndex += 1

def convertData(data):
    # Check general values:
    if data is None:
        return None
    if "user" not in data:
#         warning.w("No user found in:\n" + listToStr(data)) # Warning log because unexpected value
        return None
    # We create the new object to return:
    newObject = {}
    # We get the tweet data:
    for current in toKeep:
        newObject[current] = None
        if current in data:
            newObject[current] = data[current]
        else:
            warning.w("No " + current + " in:\n" + listToStr(data)) # Warning log because unexpected value
    # We translate some vars:
    newObject["tweet_id"] = newObject.pop("id")
    newObject["tweet_lang"] = newObject.pop("lang")
    # We get the user:
    for current in toKeepInUser:
        theKey = "user_" + current
        newObject[theKey] = None
        if current in data["user"]:
            newObject[theKey] = data["user"][current]
        else:
            warning.w("No " + current + " in user in:\n" + listToStr(data)) # Warning log because unexpected value
    # Finally we return the object:
    return newObject

def isPruned(data):
#     global allLangs
#     if data["tweet_lang"] not in allLangs:
#         allLangs.append(data["tweet_lang"])
#         warning.w(data["tweet_lang"])
    if not data["tweet_lang"].startswith("en"):
        return True
    return False

if __name__ == '__main__':
    # Get all data paths:
    allFiles = sortedGlob(inputFilesPattern) # TODO faire un sorted glob plus propre avec un os.walk
    originalFileCount = len(allFiles)
    currentOriginalIndex = 0
     
    tt = TicToc(logger=info)
    tt.tic("Starting...")
    currentConvertedData = []
    entryCount = 0
    alreadyDisplayedEntryCount = -1
     
    for currentFilePath in allFiles:
        currentOriginalIndex += 1
        jr = JsonReader(currentFilePath)
        i = 1
        for current in jr:
            if alreadyDisplayedEntryCount != entryCount and entryCount % int(entriesCountPerFile / 4) == 0:
                tt.toc("entryCount=" + str(entryCount))
                tt.toc("progression=" + str(float(currentOriginalIndex) / float(originalFileCount) * 100.0) + "%")
                alreadyDisplayedEntryCount = entryCount
            currentData = convertData(current)
            if currentData is not None:
                if not isPruned(currentData):
                    currentConvertedData.append(currentData)
                    entryCount += 1
            if len(currentConvertedData) > entriesCountPerFile:
                storeData(currentConvertedData, outputPath, logger=info)
                currentConvertedData = []
            i += 1
    storeData(currentConvertedData, outputPath, logger=info)
    # TODO faire un logging qui fonctionne avec nohup
    # La commande nohup marche pas en ssh.....
    
    info.p("Starting rename all files...")
    normalizeNumericalFilePaths(outputPath + "/*.bz2")
    info.p("Done")

    



