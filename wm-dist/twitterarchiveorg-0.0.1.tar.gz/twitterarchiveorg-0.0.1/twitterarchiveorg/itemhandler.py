# coding: utf-8

from datatools.url import *
from datatools.csvreader import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logWarning, logError, Logger
from systemtools.location import *
import random
import re
from databasetools.mongo import *
from twitterarchiveorg.urlgenerator import *
from collections import OrderedDict
from datatools.jsonreader import JsonReader
from systemtools.hayj import getMongoAuth
from unshortener.unshortener import *


class ItemHandler():
    """
        This class takes some init params which say if a news is an item
        And the function getItems, hasItem get tweet and return items
        The function isItem get an url and if it is an item
    """
    def __init__ \
    (
        self,
        scrapMinLength=40,
        chevronCountMax=10,
        statusAccept=["success", "timeoutWithContent"],
        defaultScrap="boilerpipe",
        titleMinLength=6,
        newsURLFilterParams={},
        logger=None,
        verbose=True
    ):
        self.verbose = verbose
        self.logger = logger
        self.newsURLFilterParams = newsURLFilterParams
        self.defaultScrap = defaultScrap
        self.titleMinLength = titleMinLength
        self.statusAccept = statusAccept
        self.chevronCountMax = chevronCountMax
        self.scrapMinLength = scrapMinLength
        self.uns = Unshortener(readOnly=True)
        self.nuf = NewsURLFilter(**newsURLFilterParams, unshortener=self.uns, logger=self.logger, verbose=self.verbose)
        (user, password, host) = getMongoAuth(user="student", hostname="datascience01")
        self.taonewsCollection = MongoCollection \
        (
            "crawling",
            "taonews",
            user=user,
            password=password,
            host=host,
            databaseRoot="crawling",
        )

    def getItems(self, tweet):
        normalizedUrls = []
        for current in getFormatedUrlsFromTweet(tweet):
            normalizedUrls.append(current["normalized_url"])
        newExpandedUrls = []
        for current in normalizedUrls:
            if self.isItem(current):
                newExpandedUrls.append(current)
        return newExpandedUrls

    def hasItem(self, tweet):
        if len(self.getItems(tweet)) > 0:
            return True
        return False

    def isItem(self, normalizedUrl):
        title = None
        status = None
        scrap = None
        row = self.taonewsCollection.findOne({"normalized_url": normalizedUrl})
        if row is None:
            return False
        try:
            status = row["status"]
            title = row["status"]
            if self.defaultScrap == "boilerpipe":
                scrap = row["scrap"]["boilerpipe"]["text"]
        except:
            return False
        if title is None or len(title.strip()) < self.titleMinLength:
            return False
        if normalizedUrl is None or normalizedUrl.strip() == "":
            return False
        if scrap is None or len(scrap.strip()) < self.scrapMinLength:
            return False
        if scrap.count("<") > self.chevronCountMax:
            return False
        if status not in self.statusAccept:
            return False
        if not self.nuf.isNews(normalizedUrl):
            return False
        return True



if __name__ == '__main__':
    itemHandler = ItemHandler()
    i = 0
    for current in JsonReader(sortedGlob(dataDir() + "/TwitterArchiveOrg/Converted3.3/*.bz2")):
        printLTS(itemHandler.getItems(current))
        if i == 500:
            break
        i += 1


