# coding: utf-8


# Sur octods
# nn -o nohup-sparktomongo.out pew in twitterarchiveorg-venv python /home/hayj/wm-dist-tmp/TwitterArchiveOrg/twitterarchiveorg/sparktomongo.py


import sys, os; sys.path.append("/".join(os.path.abspath(__file__).split("/")[0:-2]))


from systemtools.hayj import *
from systemtools.basics import *
from systemtools.location import *
from systemtools.system import *
from systemtools.logger import *
from datatools.json import *
from databasetools.mongo import *
from twitterarchiveorg.itemhandler import *
from twitterarchiveorg import __version__

def printSize():
    print("db size = " + str(taotweets.size()))


logger = Logger("sparktomongo.log")
theConverted = "Converted3.3"
jr = JsonReader(sortedGlob(dataDir() + "/TwitterArchiveOrg/" + theConverted + "/*.bz2"))
if isHostname("hjlat"):
    (user, password, host) = (None, None, None) # mongod-start
else:
    (user, password, host) = getMongoAuth("hayj", "datascience01")
taotweets = MongoCollection("taotweets",
                             theConverted.lower(),
                             version=__version__,
                             user=user, password=password, host=host,
                             indexNotUniqueOn=["user_id", "timestamp"],
                             giveTimestamp=False,
                             logger=logger)

taotweets.resetCollection(security=isHostname("datasc"))

# items, timestamp, user_id
itemHandler = ItemHandler()
count = 0
for tweet in jr:
    toInsert = {}
    toInsert["tweet"] = tweet
    toInsert["user_id"] = tweet["user_id"]
    toInsert["timestamp"] = tweet["timestamp"]
    toInsert["items"] = itemHandler.getItems(tweet)
    count += len(toInsert["items"])
    taotweets.insert(toInsert)
    if isHostname("hjlat") and getRandomFloat() > 0.95:
        if not askContinue(False):
            break
    log("item count = " + str(count), logger)

taotweets.show(3)

# Converted3.3 : 207830 tweets, 58078 items (pas unique, il peut y avoir 2 fois le même)
