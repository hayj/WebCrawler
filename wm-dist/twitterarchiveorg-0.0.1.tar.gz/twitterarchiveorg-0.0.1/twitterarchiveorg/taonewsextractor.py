# nn pew in twitterarchiveorg-venv python /home/hayj/wm-dist-tmp/TwitterArchiveOrg/twitterarchiveorg/taonewsextractor.py

import sys, os; sys.path.append("/".join(os.path.abspath(__file__).split("/")[0:-3]))

# from domainduplicate import config as ddConf
# ddConf.useMongodb = False
from systemtools.basics import *
from systemtools.file import *
from systemtools.location import *
from systemtools.logger import *
from datatools.jsonutils import *
from twitternewsrec.user.topuser import *
from twitternewsrec.user.twitteruser import *
from twitternewsrec.extractor.utils import *
from datastructuretools.processing import *
from datatools.url import *
from newstools.newsscraper import *
import json


def read():
	max = 10
	i = 0
	for current in sortedGlob("/home/hayj/Data/News/taonews/*.bz2"):
		for row in NDJson(current):
			printLTS(reduceDictStr(row, 150))
			if i == max:
				exit()
			i += 1

def generate():

	TEST = isHostname("hjlat")
	logger = Logger("taonewsextractor.log")
	(user, password, host) = getStudentMongoAuth()
	taonews = MongoCollection("crawling", "taonews",
		user=user, password=password, host=host, logger=logger)
	ids = taonews.distinct("_id")
	dataDirPath = dataDir() + "/News/taonews"
	removeDirSecure(dataDirPath)
	mkdir(dataDirPath)
	newsScraper = NewsScraper(logger=logger)
	urlParser = URLParser(logger=logger)
	nuf = NewsURLFilter(logger=logger, useUnshortener=False)
	addedCount = 0
	batchMaxSize = 10000
	if TEST:
		batchMaxSize = 10
		ids = ids[:200]
	log("len(ids): " + str(len(ids)), logger)
	f = None
	notFoundMemory = list()
	notNewsMemory = list()
	notGoodNewsMemory = list()
	exceptionMemory = list()
	idss = splitMaxSized(ids, batchMaxSize)
	part = 1
	pbar = ProgressBar(len(ids), printRatio=0.01, logger=logger)
	for ids in idss:
		f = NDJson(dataDirPath + "/taonews.part" + str(part) + ".ndjson.bz2")
		for id in ids:
			data = taonews.findOne({"_id": id})
			if data is None or not dictContains(data, "last_url"):
				notFoundMemory.append(id)
			else:
				try:
					if nuf.isNews(data["last_url"]):
						if data["status"] == "error404":
							data["status"] = "success"
						newData = dict()
						newData["title"] = data["title"]
						newData["status"] = data["status"]
						newData["scrap"] = newsScraper.smartScrap(data["html"])
						lastUrl = urlParser.normalize(data["last_url"])
						url = urlParser.normalize(data["twitter_expanded_url"])
						newData["lastUrl"] = lastUrl
						newData["url"] = url
						newData["lastUrlDomain"] = urlParser.getDomain(lastUrl)
						newData["urlDomain"] = urlParser.getDomain(url)
						if isGoodNews(newData):
							storableNewData = dictToMongoStorable(newData)
							f.append(storableNewData)
							addedCount += 1
						else:
							notGoodNewsMemory.append(newData["lastUrl"])
					else:
						# logger.e(data["last_url"] + " is not a news.")
						notNewsMemory.append(data["last_url"])
				except Exception as e:
					logException(e, logger)
					exceptionMemory.append(data["last_url"])
			pbar.tic()
		part += 1

	# log("notFoundMemory:\n" + lts(notFoundMemory), logger)
	# log("\n" * 3, logger)
	# log("notGoodNewsMemory:\n" + lts(notGoodNewsMemory), logger)
	# log("\n" * 3, logger)
	# log("exceptionMemory:\n" + lts(exceptionMemory), logger)
	# log("\n" * 3, logger)
	log("notNewsMemory len: " + str(len(notNewsMemory)), logger)
	log("notNewsMemory: " + reducedLTS(notNewsMemory), logger)
	log("notFoundMemory len: " + str(len(notFoundMemory)), logger)
	log("notGoodNewsMemory len: " + str(len(notGoodNewsMemory)), logger)
	log("exceptionMemory len: " + str(len(exceptionMemory)), logger)
	log("addedCount: " + str(addedCount), logger)
	log("last part: " + str(part), logger)



if __name__ == '__main__':
	generate()