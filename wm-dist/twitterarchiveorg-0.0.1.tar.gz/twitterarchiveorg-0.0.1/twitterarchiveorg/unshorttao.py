# coding: utf-8

import sys, os; sys.path.append("/".join(os.path.abspath(__file__).split("/")[0:-2]))


# nn pew in twitterarchiveorg-venv python ~/wm-dist-tmp/TwitterArchiveOrg/twitterarchiveorg/unshorttao.py

from systemtools.basics import *
from datatools.json import *
from datatools.url import *
from datatools.csvreader import *
from systemtools.file import *
from systemtools.location import *
from systemtools.system import *
from systemtools.logger import *
from datatools.url import *
from newstools.newsurlfilter import *
from twitterarchiveorg.urlgenerator import *
import random
from unshortener.unshortener import *
import time


def seeUnshortenerDatabase():
    uns = Unshortener()
    nuf = NewsURLFilter()
    newsCount = 0
    count = 0
    for key, current in uns.data.data.items():
        print(key + " " + str(current["value"]["status"]))
        unshortedUrl = current["value"]["lastUrl"]
        toPrint = unshortedUrl
        thisIsANews = nuf.isNews(unshortedUrl)
        if thisIsANews:
            toPrint += "\t######## this is a news ########"
            newsCount += 1
        else:
            count += 1
        print(toPrint)
        print()
    print("newsCount=" + str(newsCount))
    print("count=" + str(count))
    print("total=" + str(newsCount + count))
    print("news percent=" + str(newsCount / (newsCount + count) * 100))
    exit()


if __name__ == '__main__':
#     seeUnshortenerDatabase()
    nuf = NewsURLFilter()
    logger = Logger("unshorttao-" + getRandomStr() + ".log")
    uns = Unshortener(logger=logger)
#     dataFiles = sortedGlob(dataDir() + "/TwitterArchiveOrg/Converted3.3/*.bz2")
    dataFiles = sortedGlob(dataDir() + "/TwitterArchiveOrg/Converted2/*.bz2")
    count = 0
    for tweet in JsonReader(dataFiles):
        urls = getNormalizedUrlsFromTweet(tweet)
        for url in urls:
            if uns.isShortener(url):
                result = uns.unshort(url)
                if result["status"] == 200:
                    log("normalized_url: " + url, logger)
                    unshortedUrl = result["lastUrl"]
                    log("unshortedUrl: " + str(unshortedUrl), logger)
                    thisIsANews = nuf.isNews(unshortedUrl)
                    log("thisIsANews: " + str(thisIsANews), logger)
                    if thisIsANews:
                        print("!!!!!!!!!!!!!!!!!!!!!!!!!!")
                    count += 1
                else:
                    log("normalized_url: " + url + " FAILED!", logger)
                    log(listToStr(result), logger)
                log("\n\n-\n\n", logger)

    log(str(count), logger)
    uns.close()


    # On a 50% des shorted urls qui sont des news dans Converted3.3 avec la version isNews de decembre 2017




















