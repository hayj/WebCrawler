# coding: utf-8

from datatools.url import *
from datatools.csvreader import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logWarning, logError, Logger
from systemtools.location import *
import random
import re
from databasetools.mongo import *
from twitterarchiveorg.urlgenerator import *

class ItemHandler():
    def __init__ \
    (
        self,
        scrapMinLength=40,
        chevronCountMax=10,
        statusAccept=["success", "timeoutWithContent"],
        defaultScrap="boilerpipe",
        titleMinLength=6
    ):
        self.defaultScrap = defaultScrap
        self.titleMinLength = titleMinLength
        self.statusAccept = statusAccept
        self.chevronCountMax = chevronCountMax
        self.scrapMinLength = scrapMinLength
        self.nuf = NewsURLFilter()
        if isHostname("datasc"):
            host = "localhost"
        else:
            host = "212.129.44.40"
            
        self.taonewsCollection = MongoCollection \
        (
            "crawling",
            "taonews",
            user="student",
            password="CScas21ù",
            host=host,
            databaseRoot="crawling",
        )
        
    def getItems(self, tweet):
        expandedUrls = []
        for current in getFormatedUrlsFromTweet(tweet):
            expandedUrls.append(current["expanded_url"])
        newExpandedUrls = []
        for current in expandedUrls:
            if self.isItem(current):
                newExpandedUrls.append(current)
        return newExpandedUrls

    def hasItem(self, tweet):
        if len(self.getItems(tweet)) > 0:
            return True
        return False
    
    def isItem(self, expandedUrl):
        title = None
        status = None
        scrap = None
        row = self.taonewsCollection.findOne({"expanded_url": expandedUrl})
        if row is None:
            return False
        try:
            status = row["status"]
            title = row["status"]
            if self.defaultScrap == "boilerpipe":
                scrap = row["scrap"]["boilerpipe"]["text"]
        except:
            return False
        if title is None or len(title.strip()) < self.titleMinLength:
            return False
        if expandedUrl is None or expandedUrl.strip() == "":
            return False
        if scrap is None or len(scrap.strip()) < self.scrapMinLength:
            return False
        if scrap.count("<") > self.chevronCountMax:
            return False
        if status not in self.statusAccept:
            return False
        if not self.nuf.isNews(expandedUrl):
            return False
        return True
    


# Voir fichier itemtest pour l'utilisation de cette 

