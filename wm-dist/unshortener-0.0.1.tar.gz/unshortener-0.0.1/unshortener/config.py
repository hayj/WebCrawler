host = None
hostname = "datascience01"
user = "hayj"
password = None