noSandbox = False
torPortCount = 100