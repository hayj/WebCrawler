
from systemtools.basics import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logWarning, logError, Logger
from systemtools.location import *
from systemtools.system import *

proxiesDataSubDir = "/Misc/crawling/proxies"

def getProxiesPath(proxiesPath=None):
    if proxiesPath is not None:
        return proxiesPath
    else:
        return dataDir() + proxiesDataSubDir + "/proxies-renew.txt"



def getRandomProxy(proxiesPath=None):
    proxiesPath = getProxiesPath(proxiesPath)
    allProxies = getProxies(proxiesPath)
    return random.choice(allProxies)

def getProxies(proxiesPath=None, removeFailedProxies=True, defaultType="http"):
    proxiesPath = getProxiesPath(proxiesPath)
    # If the file exist, we parse it, one proxie by line (165.231.108.5:80:user:pass)
    if fileExists(proxiesPath):
        proxies = []
        proxiesTextList = fileToStrList(proxiesPath)
        for current in proxiesTextList:
            try:
                proxies.append(proxyToDict(current))
            except Exception as e:
                pass
        if removeFailedProxies:
            failedPath = dataDir() + proxiesDataSubDir + "/proxies-failed.txt"
            if isFile(failedPath):
                proxiesFailed = getProxies(proxiesPath=failedPath, removeFailedProxies=False)
                proxies = listSubstract(proxies, proxiesFailed)
        return proxies
    return None



def proxyToDict(proxyStr, defaultType="http"):
    """
        A str proxy is formated like these examples:
         * 107.150.77.161:80:octopeek:librepost
         * 107.150.77.161:80:::
         * 107.150.77.161:80:::http
         * 107.150.77.161:80:::http
    """
    if isinstance(proxyStr, dict):
        return proxyStr
    proxyStr = proxyStr.strip()
    theDict = {}
    theTuple = proxyStr.split(":")
    assert len(theTuple) == 4 or len(theTuple) == 5
    theDict["ip"] = theTuple[0]
    theDict["port"] = theTuple[1]
    theDict["user"] = None
    theDict["password"] = None
    if len(theTuple) > 2:
        theDict["user"] = theTuple[2]
        theDict["password"] = theTuple[3]
    if len(theTuple) >= 5:
        theDict["type"] = theTuple[4]
    else:
        theDict["type"] = defaultType
    return theDict

def proxyToStr(proxyDict, hidePassword=True, defaultType="http"):
    if isinstance(proxyDict, str):
        return proxyDict
    assert "ip" in proxyDict and "port" in proxyDict
    proxyDict = dict(proxyDict)
    if hidePassword:
        proxyDict["password"] = ""
    if not dictContains(proxyDict, "user"):
        proxyDict["user"] = ""
    result = proxyDict["ip"] + ":" + proxyDict["port"]
    result += ":" + proxyDict["user"] + ":" + proxyDict["password"]
    if not dictContains(proxyDict, "type"):
        proxyDict["type"] = defaultType
    result += ":" + proxyDict["type"]
    return result

def getProxiesProd():
    return getProxies(dataDir() + proxiesDataSubDir + "/proxies-prod.txt")
def getProxiesTest():
    return getProxies(dataDir() + proxiesDataSubDir + "/proxies-test.txt")
def getProxiesRenew():
    return getProxies(dataDir() + proxiesDataSubDir + "/proxies-renew.txt")
def getProxiesLinkedin():
    return getProxies(dataDir() + proxiesDataSubDir + "/proxies-linkedin.txt")
def getAllProxies(*args, **kwargs):
    return getProxiesAll(*args, **kwargs)
def getProxiesAll():
    return getProxiesRenew() + getProxiesLinkedin()


if __name__ == '__main__':
#     testIsHtmlOK()
#     proxies = getProxies(dataDir() + proxiesDataSubDir + "/proxies-renew.txt")
#     proxies = getProxiesRenew()
#     print(len(proxies))


    print(proxyToDict("107.150.77.161:80:octopeek:librepost"))
    print(proxyToDict("107.150.77.161:80:::"))
    print(proxyToDict("107.150.77.161:80:::http"))
    print(proxyToDict("107.150.77.161:80:::http"))

