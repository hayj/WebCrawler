

import requests
import eventlet
eventlet.monkey_patch(socket=True)
from systemtools.duration import *
from systemtools.logger import *
from hjwebbrowser.proxy import *
# from hjwebbrowser.tor import *
from threading import Thread
from datatools.url import *



urls = URLParser().strToUrls(fileToStr(getExecDir() + "/urls.txt"))


# def patchSocket():
# 	if not eventlet.patcher.is_monkey_patched("socket"):
# 		eventlet.monkey_patch(socket=True)


def request(url, p, timeout=10):
	try:
		r = None
		proxies = {'http': p.toScheme(), 'https': p.toScheme()}
		with eventlet.Timeout(timeout, Exception("Eventlet timeout")):
			r = requests.get(url, proxies=proxies, verify=False, timeout=timeout)
		if r is not None:
			print(url + " --> " + str(r.content[:15]))
	except Exception as e:
		print(url + " --> " + str(e))




urls = urls[:10]
urls += ["http://ipv4.download.thinkbroadband.com/1GB.zip"]

tt = TicToc()
tt.tic()

threads = []
i = 0
allProxies = getAllProxies()

for url in urls:
	thread = Thread(target=request, args=(url, allProxies[i],))
	threads.append(thread)
	i += 1




for current in threads:
	current.start()
for current in threads:
	current.join()




tt.toc()
