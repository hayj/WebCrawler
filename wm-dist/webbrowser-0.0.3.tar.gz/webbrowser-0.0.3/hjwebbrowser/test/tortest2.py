################### Tor test ################
# Warning: actually HTTPBrowser try to use Tor but on server which doesn't have tor installed, it will use the public ip of the server, the test proof:
from domainduplicate import config as ddConf
ddConf.useMongodb = False
from systemtools.basics import *
from hjwebbrowser.httpbrowser import *
# from hjwebbrowser.tor import *
# tor = Tor(portCount=3)
# tor.stop()
# p = tor.getRandomProxy()
b = HTTPBrowser(proxy=getRandomProxy(), maxRetryWithTor=1)
printLTS(b.html("https://api.ipify.org?format=json"))
# tor.stop()
##############################################





# from domainduplicate import config as ddConf
# ddConf.useMongodb = False
# from systemtools.basics import *
# from hjwebbrowser.httpbrowser import *
# from hjwebbrowser.tor import *
# tor = Tor(portCount=3, startPort=1100)
# p = tor.getRandomProxy()
# print(p.toScheme())
# b = HTTPBrowser(proxy=p)
# printLTS(b.html("https://api.ipify.org?format=json"))





# import requests
# from hjwebbrowser.tor import *
# # print(getUsedPorts())
# tor = Tor(portCount=1)
# url = "https://api.ipify.org?format=json"
# p = tor.getRandomProxy()
# proxies = {'http': p.toScheme(), 'https': p.toScheme()}
# r = requests.get(url, proxies=proxies)
# print(r.content)



