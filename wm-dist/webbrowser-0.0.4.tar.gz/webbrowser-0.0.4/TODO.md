# sometime phantomjs driver block on a self.driver.get(url) even a timeout was set, for exemple these urls :
# ["http://nypost.com/2017/10/07/inside-the-mean-girls-culture-that-destroyed-sex-and-the-city/", "http://abcnews.go.com/Entertainment/wireStory/resignations-fallout-grow-embattled-producer-weinstein-50351532"]
# When you use phantomjs on these urls, the get take an infinite time, so a memory heap in the crawler
# And when we use a python thread timeout on the get, we can't quit() the driver...
# And we can't kill the browser in command line because we don't know which phantomjs it is...
# DONE DONE DONE DONE DONE DONE DONE DONE !!!!!!!!! with pid and threaded timeouts

# TODO chrome header (user agent done, but other header element can't be set)

# TODO phantomjs is easily detected by google and others...
# phantomjs is slow and less reliable but take less proc

# TODO Chrome too much proc...

# Par contre pour la détection de phantomjs par google aucune idée de comment ils font,
# je sais juste que c'est pas le header, c'est pas les proxies, c'est pas
# un comportement non humain puisqu'il y a juste une requête, ça doit être qqch de plus
# basique comme une option genre ne pas charger les image ou le cache qqch comme ça.






# Probleme de timeout sur requests :

<https://github.com/requests/requests/issues/1577>

via Tor, gros loading time sur ces urls qui sont des mp4 et gros gif de 7Mo :

<http://go.wisc.edu/2xa717>
<https://go.wisc.edu/h825k9> --> <https://cimss.ssec.wisc.edu/goes/blog/wp-content/uploads/2018/01/180117_terra_modis_truecolor_falsecolor_Deep_South_snow_anim.gif>





Faire ça en mettant un max size en param init de HTTPBrowser

	If you set stream=False, Requests will endeavour to download the entire Request body before it returns, which will fail. =) What specific dangling connection problems do you have? (Additionally, stream=False is the default behaviour, so you shouldn't need to explicitly set it).

		As for sample code, try:

		import time
		import requests

		url = "http://www.iva.net/blog/"
		timeout = 90
		body = []

		start = time.time()
		r = requests.get(url, verify=False, stream=True)

		for chunk in r.iter_content(1024): # Adjust this value to provide more or less granularity.
		    body.append(chunk)

		    if time.time() > (start + timeout):
		        break # You can set an error value here as well if you want.

		content = b''.join(body)

	On my machine this downloads roughly 60MB of data before breaking out. Don't make the mistake I did and print the whole thing out. It takes a while. grin







OUUUUUUUUU



Faire ça:

	import requests
	import eventlet
	eventlet.monkey_patch()

	with eventlet.Timeout(10):
	    requests.get("http://ipv4.download.thinkbroadband.com/1GB.zip", verify=False)


TODO tester concretement avec tor et requests dans un script