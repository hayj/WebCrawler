noSandbox = False
torPortCount = 10