from webcrawler.httpbrowser import *
from webcrawler.utils import *
from systemtools.basics import *
from systemtools.file import *

logger = Logger("crawler404.log")

# Here you get a lot of start urls:
allStartUrls = []
for filePath in \
[
    "/home/hayj/Data/Misc/news-website-list/data/google-news-sources.csv",
    "/home/hayj/Data/Misc/news-website-list/data/list.csv",
]:
    cr = CSVReader(filePath)
    for row in cr:
        if  "lang" in row and row["lang"] == "en":
            if not row["url"].startswith("http"):
                row["url"] = "http://" + row["url"]
            allStartUrls.append(row["url"])
log(listToStr(allStartUrls), logger)

# Here you get all proxies ():
proxies = getProxies("/home/student/proxies.txt")
# proxies = getProxies()

# Now you download 200 urls per site and only one 404:
for startUrl in allStartUrls:
    randomProxy = random.choice(proxies)
    b = HTTPBrowser(proxy=randomProxy, retryWithoutProxyIf407=False, retryWithPort80If407=True)
    log("Trying to get " + startUrl, logger)
    result = b.get(startUrl)
    # Don't forget to check HTTP 200 response:
    log(listToStr(reduceDictStr(result)), logger)
    log(result["status"], logger)


    break

    # And you store in "ok" and "404"....
    # Use beautiful soup to find new urls in the same domain...

    # To generate the random url 404, use urlparse library, get the index page (http://toto.com)
    # And add a random string after a "/"


    # IMPORTANT: use proxies. DON'T use the server ip !!!!
    # IMPORTANT: let retryWithoutProxyIf407 as False to don't use the server ip
    # IMPORTANT: crawl 200 DIFFERENT urls per site and only one 404 (check responses)
