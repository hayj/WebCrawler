# Phantomjs deprecation

If phantomjs doesn't works, you can go back to selenium==3.8.0 and phantomjs==2.1.1