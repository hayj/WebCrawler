













########## OTHERS ################


POUR L'API :
lastCrawlingTimestamp
crawling : une liste avec des versions, une methode (humandriver ou autre...), le html, le titre,
Scrapping : un contenu scrappé propre avec pareil une version, une methode etc
deleteAfter : en jours
Le domaine etc
Un type : twitter user ou autre



TODO https://pypi.python.org/pypi/fake-useragent

############### NOTES ################




# Notes : crawler.driver.implicitly_wait(3) marche pas vraiment
# Par contre un sleep et crawler.driver.manage().timeouts().pageLoadTimeout(10); fonctionne


242835 au total
