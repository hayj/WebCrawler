from webcrawler.crawler import *
from systemtools.basics import *

browserParams = {
    'chromeDriverPath': '/home/hayj/Programs/browserdrivers/chromedriver',
    'phantomjsPath': '/home/hayj/Programs/headlessbrowsers/phantomjs-2.1.1-linux-x86_64/bin/phantomjs',
    'domainDuplicateParams':
        {
            "user": None, "password": None, "host": 'localhost',
        }
}
pageLoadTimeout = 45  # IMPORTANT
browsersDriverType = DRIVER_TYPE.chrome  # IMPORTANT
queueMinSize = 1000
maxRetryFailed = 4  # IMPORTANT
browserMaxDuplicatePerDomain = 200  # IMPORTANT

def crawlingCallback(data, browser=None):
    try:
        # We get the status:
        printLTS(reduceDictStr(data))
    except Exception as e:
        logException(e, location="crawlingCallback")


crawler = Crawler(
        ['https://github.com/hayj'],
        pageLoadTimeout=pageLoadTimeout,
        browsersVerbose=True,
        queueMinSize=queueMinSize,
        stopCrawlerAfterSeconds=1000,
        crawlingCallback=crawlingCallback,
        maxRetryFailed=maxRetryFailed,
        browserMaxDuplicatePerDomain=browserMaxDuplicatePerDomain,
        useProxies=True,
        sameBrowsersParallelRequestsCount=True,
        useHTTPBrowser=False,
        browsersDriverType=browsersDriverType,
        browserParams=browserParams,
)

crawler.start()
