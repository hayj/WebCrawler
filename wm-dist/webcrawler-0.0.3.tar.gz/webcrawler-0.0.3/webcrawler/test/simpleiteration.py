# coding: utf-8

from datatools.json import *
from datatools.url import *
from machinelearning.bandit import *
from datastructuretools.basics import *
from datastructuretools.setqueue import *
from machinelearning.function import *
from datatools.csvreader import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logWarning, logError, Logger
from systemtools.location import *
from systemtools.system import *
import selenium
from selenium import webdriver
import sh
import random
import html2text
import re
import ipgetter
from threading import Thread, Lock, Semaphore, active_count
import math
import numpy
from webcrawler.crawler import *
from hjwebbrowser.utils import *
from webcrawler.browser import *
from queue import *
from databasetools.mongo import *
from webcrawler.honeypot import *
from webcrawler.sample.taonews import *
from webcrawler.crawler import *
from databasetools.mongo import *
from newstools.newsscraper import *
from newstools.newsurlfilter import *
from twitterarchiveorg.urlgenerator import *
from webcrawler.sample import __version__




if __name__ == '__main__':
#     execCrawler()
#      showLines()
    iterOnDatabase()


